package com.dh.miblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiblogApplicationTests {

	@Test
	void contextLoads() {
	}

}
