package com.dh.entidades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntidadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
