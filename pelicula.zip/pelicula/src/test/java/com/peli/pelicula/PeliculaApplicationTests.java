package com.peli.pelicula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeliculaApplicationTests {

	@Test
	void contextLoads() {
	}

}
