package com.springbootMVCmio.springbootMCVmio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMcVmioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMcVmioApplication.class, args);
	}

}
