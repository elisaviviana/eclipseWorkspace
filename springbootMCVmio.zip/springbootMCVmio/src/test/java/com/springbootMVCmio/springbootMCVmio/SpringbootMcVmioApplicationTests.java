package com.springbootMVCmio.springbootMCVmio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMcVmioApplicationTests {

	@Test
	void contextLoads() {
	}

}
