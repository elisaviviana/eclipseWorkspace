package com.springbootMVC.springbootMCV1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMcv1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
